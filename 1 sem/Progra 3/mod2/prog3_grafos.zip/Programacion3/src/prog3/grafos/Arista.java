package prog3.grafos;

public interface Arista<T> {

	
	public Vertice<T> verticeDestino();
	
	public int peso();

}
