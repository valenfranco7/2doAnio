package prog3.grafos;

public interface Vertice<T> {
	
	public T dato();
	public void setDato(T unDato);
	public int posicion();

}
